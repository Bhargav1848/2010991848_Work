const express = require("express"); //epxress used for making APIs
const bodyParser = require("body-parser"); //to fetch data from form
const request = require("request"); // to making request
const db = require("./list");
app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");

app.get("/", (req, res) => {
    res.render("index", { list: db });
});

app.post("/add", (req, res) => {
    const desc = req.body.desc;
    const dead = req.body.dead;
    const item = {
        id: 4,
        description: desc,
        time: "time 3",
        deadline: dead,
        status: false,
    };
    db.push(item);
    res.redirect("/");
});

app.get("/add", (req, res) => {
    res.render("add");
});

app.get("/delete/:id", (req, res) => {
    var desc = "";
    var dead = "";
    for (var i = 0; i < db.length; i++) {
        if (db[i].id == req.params.id) {
            db.splice(i, 1);
            break;
        }
    }
    res.redirect("/");
});

app.get("/edit/:id", (req, res) => {
    var desc = "";
    var dead = "";
    for (var i = 0; i < db.length; i++) {
        if (db[i].id == req.params.id) {
            desc = db[i].description;
            dead = db[i].deadline;
        }
    }
    res.render("edit", { description: desc, id: req.params.id });
});

app.post("/edit/:id", (req, res) => {
    const desc = req.body.desc;
    const dead = req.body.dead;
    for (var i = 0; i < db.length; i++) {
        if (db[i].id == req.params.id) {
            if (desc != db[i].description) db[i].description = desc;
            if (dead != db[i].deadline) db[i].deadline = dead;
        }
    }
    res.redirect("/");
});

// app.get("/add", (req, res) => {
//     res.send("add page");
// });

app.listen(5020);