// var currentdate = new Date();
const db = [{
        id: 1,
        description: "Add list",
        time: "time",
        deadline: "12/14/22",
        status: true,
    },
    {
        id: 2,
        description: "Work on Project",
        time: "time",
        deadline: "12/14/22",
        status: false,
    },
];
module.exports = db;